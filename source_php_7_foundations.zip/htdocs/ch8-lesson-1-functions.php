<?php

$message = strlen("Stefan is teaching you some.");





?>
<!DOCTYPE html>
<html>
	<head>
		<title>Ch8 PHP Functions</title>
	
	</head>
	<body>

		<h1>PHP Functions</h1>

		<?php echo $message; ?>

	
		
	</body>

</html>