<!DOCTYPE html>
<html>
	<head>
		<title>Ch7 The form</title>
	
	<style type="text/css">

		input {display: block; margin-bottom: 10px;}

	</style>

	</head>
	<body>

		<h1>PHP Form Processing</h1>

		<form method="POST" action="ch7-lesson-1-conditionals.php">

			Name: <input type="text" name="name">

			Password: <input type="password" name="password">

			<input type="submit">


		</form>	

		
	</body>
</html>