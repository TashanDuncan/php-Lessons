<!DOCTYPE html>
<html>
	<head>
		<title>Ch4 PHP</title>
	
	</head>
	<body>

		<h1>PHP includes and PHP configurations</h1>

		<?php

		/*
			PHP ini settings:

			date.timezone = UTC
			Error handling and logging - > display_errors =  On


		*/
		
				$abc = "Stef";

				$qwery = 122;
				echo $qwery;


		?>

		
	</body>
</html>