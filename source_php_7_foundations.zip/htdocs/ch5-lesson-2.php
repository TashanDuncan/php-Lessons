<!DOCTYPE html>
<html>
	<head>
		<title>Ch5 PHP</title>
	
	</head>
	<body>

		<h1>PHP Arrays</h1>

		<?php

			$foodCart = array("bananas","burgers","chicken", "butter");

			echo "How many items in our cart: " . count($foodCart);

		

		?>

		
	</body>
</html>