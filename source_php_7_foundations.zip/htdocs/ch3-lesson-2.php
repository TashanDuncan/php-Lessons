<!DOCTYPE html>
<html>
	<head>
		<title>Ch3 PHP</title>
	
	</head>
	<body>

		<h1>PHP variables - lesson 2</h1>

		<?php
		
			$numberfive = "Stefan";
			$newVar = 5;
			$floatingVar = 10.4;


		?>

		
	</body>
</html>