<!DOCTYPE html>
<html>
	<head>
		<title>Ch1 PHP</title>
	
	</head>
	<body>

		<h1>PHP comments and case</h1>


		<?php


			// This is a single-line comment

			# This is also a single-line comment

			/*
			This is a multiple-lines comment block
			that spans over multiple
			lines
			*/

			// You can also use comments to leave out parts of a code line
			$x = 5 /* + 15 */ + 5;

			$secretVariable = "password";

			echo $x;

		

		?>




		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
		
	</body>
</html>