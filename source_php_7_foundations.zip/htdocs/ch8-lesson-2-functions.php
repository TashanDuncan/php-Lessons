<?php

//$message = date("m");

//$message = date("y");

$message =  scandir("C:")

/* 

Where to research other PHP functions: 
http://www.w3schools.com/php/

*/



?>
<!DOCTYPE html>
<html>
	<head>
		<title>Ch8 PHP Functions</title>
	
	</head>
	<body>

		<h1>PHP Functions</h1>

		<?php echo print_r($message); ?>

	
		
	</body>

</html>