<!DOCTYPE html>
<html>
	<head>
		<title>Ch6 PHP</title>
	
	</head>
	<body>

		<h1>PHP Form Processing</h1>

		<form method="POST" action="ch6-lesson-5-form-response.php">

			Name: <input type="text" name="name">

			<br>

			Password: <input type="password" name="password">

			<br>

			<input type="submit">


		</form>	

		
	</body>
</html>