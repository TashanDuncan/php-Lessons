<!DOCTYPE html>
<html>
	<head>
		<title>Ch6 PHP</title>
	
	</head>
	<body>

		<h1>Welcome to the server!!</h1>

		<?php

		
		
		?>


		
	</body>
</html>