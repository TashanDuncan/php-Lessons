<!DOCTYPE html>
<html>
	<head>
		<title>Ch4 PHP</title>
	
	</head>
	<body>

		<?php include_once 'ch4-lesson-3-inc.php'; ?>


		<h1>PHP includes and PHP configurations</h1>

		<?php include_once("ch4-lesson-3-inc.php"); ?>

		<?php

			echo $password;
		?>


		
	</body>
</html>