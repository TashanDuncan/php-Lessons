<!DOCTYPE html>
<html>
	<head>
		<title>Ch5 PHP</title>
	
	</head>
	<body>

		<h1>PHP Arrays</h1>

		<?php

			$food = array("bannas","burgers","chicken", 6);

			echo "What's in the array: " . $food[0];

			$food1 = "bananas";
			$food2 = "fries";
			$food3 = "berries";

		?>

		
	</body>
</html>